# Supabase + GitHub Integration - Casinha das Letras

## Como ligar repositório no Supabase Dashboard

1. Vai em https://supabase.com/dashboard/project/vxtxabbjlxirrbgkctqn
2. No menu esquerdo > Database > Migrations > Connect repository
3. Escolhe angospilla-lang/Casinha-das-Letras---Plataforma-2026-27
4. Branch: main

## Migrations necessárias

Corre no SQL Editor (já está em reparo-duplicados-casinha.html):

-- Policy DELETE
DROP POLICY IF EXISTS "direcao pode apagar alunos" ON alunos;
CREATE POLICY "direcao pode apagar alunos"
ON alunos FOR DELETE TO authenticated
USING (get_my_role() IN ('direcao'));

-- Tabelas Vendus + Documentos Oficiais
CREATE TABLE IF NOT EXISTS faturas (
  id uuid primary key default gen_random_uuid(),
  aluno_id uuid references alunos(id),
  numero text, recibo_numero text, total numeric,
  metodo text, data_pagamento date default current_date,
  vendus_id text, vendus_pdf_url text, status text default 'Pago',
  created_at timestamptz default now()
);

CREATE TABLE IF NOT EXISTS documentos_oficiais (
  id uuid primary key default gen_random_uuid(),
  aluno_id uuid references alunos(id),
  tipo text, numero text, conteudo jsonb, qr_code text,
  vendus_validado boolean default false,
  created_at timestamptz default now()
);

CREATE TABLE IF NOT EXISTS presencas_mensal (
  id uuid primary key default gen_random_uuid(),
  aluno_id uuid references alunos(id),
  mes int, ano int, dias jsonb, total int, presencas int,
  created_at timestamptz default now()
);

-- RLS
ALTER TABLE faturas ENABLE ROW LEVEL SECURITY;
ALTER TABLE documentos_oficiais ENABLE ROW LEVEL SECURITY;
ALTER TABLE presencas_mensal ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "direcao tudo faturas" ON faturas;
CREATE POLICY "direcao tudo faturas" ON faturas FOR ALL TO authenticated USING (get_my_role() IN ('direcao','financeiro'));
